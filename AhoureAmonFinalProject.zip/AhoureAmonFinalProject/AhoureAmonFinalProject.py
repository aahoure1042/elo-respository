"""
 Project: Fitness & Nutrition Tracker
 Author: Amon Ahoure
 Issued Date: 3/8/2025
 Description: This Tkinter-based application allows users 
 to log exercise and meal details, track their calorie 
 balance, and visualize their progress using Matplotlib.
 
""" 

import os
from PIL import Image, ImageTk  # For handling images in Tkinter
import tkinter as tk  # GUI library
from tkinter import messagebox  # For displaying error messages
import matplotlib.pyplot as plt  # For displaying graphs
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # Embedding Matplotlib into Tkinter

# Function: load_image
# Purpose: Loads an image from the Downloads folder and resizes it for the GUI.
def load_image(filename, size=(100, 100)):
    file_path = os.path.join(os.path.expanduser("~"), "Downloads", filename)  # Define file path
    if os.path.exists(file_path):  # Check if file exists
        return ImageTk.PhotoImage(Image.open(file_path).resize(size))  # Load and resize the image
    else:
        messagebox.showerror("Error", f"Image file not found: {file_path}")  # Show error if file is missing
        return None  # Return None if file is not found

# Function: open_exercise_window
# Purpose: Opens a new window for logging exercise details.
def open_exercise_window():
    window = tk.Toplevel(root)  # Create a new top-level window
    window.title("Exercise Tracker")  # Set window title

    tk.Label(window, text="Enter exercise details below:", font=("Arial", 12, "bold")).pack(pady=5)

    # Exercise Name Input
    tk.Label(window, text="Exercise Name:", font=("Arial", 10)).pack()
    exercise_entry = tk.Entry(window)  # Text field for exercise name
    exercise_entry.pack(pady=2)

    # Calories Burned Input
    tk.Label(window, text="Calories Burned:", font=("Arial", 10)).pack()
    calories_entry = tk.Entry(window)  # Text field for calories burned
    calories_entry.pack(pady=2)

    # Function: validate_and_save
    # Purpose: Validates user input and saves exercise data.
    def validate_and_save():
        name = exercise_entry.get().strip()  # Get and trim user input
        calories = calories_entry.get()  # Get calories input

        if not name:  # Ensure exercise name is not empty
            messagebox.showerror("Error", "Exercise name cannot be empty.")
            return

        if calories.isdigit() and int(calories) > 0:  # Ensure calories input is a valid number
            messagebox.showinfo("Success", "Exercise logged successfully!")  # Show success message
        else:
            messagebox.showerror("Error", "Please enter a valid positive number for calories.")  # Error message

    # Buttons for saving and closing the window
    tk.Button(window, text="Save", command=validate_and_save).pack(pady=5)
    tk.Button(window, text="Close", command=window.destroy).pack(pady=5)

# Function: open_meal_window
# Purpose: Opens a new window for logging meal details.
def open_meal_window():
    window = tk.Toplevel(root)  # Create a new window
    window.title("Meal Logger")  # Set window title

    tk.Label(window, text="Enter meal details below:", font=("Arial", 12, "bold")).pack(pady=5)

    # Meal Name Input
    tk.Label(window, text="Meal Name:", font=("Arial", 10)).pack()
    meal_entry = tk.Entry(window)  # Text field for meal name
    meal_entry.pack(pady=2)

    # Calories Consumed Input
    tk.Label(window, text="Calories Consumed:", font=("Arial", 10)).pack()
    calories_entry = tk.Entry(window)  # Text field for calories consumed
    calories_entry.pack(pady=2)

    # Function: validate_and_save
    # Purpose: Validates meal input and logs the meal.
    def validate_and_save():
        name = meal_entry.get().strip()  # Get meal name
        calories = calories_entry.get()  # Get calorie input

        if not name:  # Ensure meal name is not empty
            messagebox.showerror("Error", "Meal name cannot be empty.")
            return

        if calories.isdigit() and int(calories) > 0:  # Ensure calorie input is a valid number
            messagebox.showinfo("Success", "Meal logged successfully!")  # Show success message
        else:
            messagebox.showerror("Error", "Please enter a valid positive number for calories.")  # Error message

    # Buttons for saving and closing the window
    tk.Button(window, text="Save", command=validate_and_save).pack(pady=5)
    tk.Button(window, text="Close", command=window.destroy).pack(pady=5)

# Function: view_progress
# Purpose: Opens a new window displaying a bar chart comparing calories burned vs. consumed.
def view_progress():
    progress_window = tk.Toplevel(root)  # Create new window
    progress_window.title("Progress Tracker")  # Set title

    tk.Label(progress_window, text="Calories Burned vs. Consumed", font=("Arial", 12, "bold")).pack()

    # Sample Data
    categories = ["Exercise", "Meals"]
    values = [500, 700]  # Example calorie data

    # Create a bar chart
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.bar(categories, values, color=['blue', 'green'])
    ax.set_ylabel("Calories")
    ax.set_title("Calories Burned vs. Consumed")

    # Embed Matplotlib graph into Tkinter
    canvas = FigureCanvasTkAgg(fig, master=progress_window)
    canvas.draw()
    canvas.get_tk_widget().pack()

    tk.Button(progress_window, text="Close", command=progress_window.destroy).pack(pady=5)

# Initialize Main Window
root = tk.Tk()
root.title("Fitness & Nutrition Tracker")
root.geometry("400x500")

# Welcome Label
tk.Label(root, text="Welcome to Fitness & Nutrition Tracker!", font=("Arial", 14, "bold"), pady=10).pack()

# Load Images
exercise_photo = load_image("exercise.png")  # Load exercise image
meal_photo = load_image("meal.png")  # Load meal image

# Display Images
tk.Frame(root, height=20).pack()  # Spacer for layout
if exercise_photo and meal_photo:
    frame = tk.Frame(root)
    frame.pack()
    exercise_label = tk.Label(frame, image=exercise_photo, text="Exercise", compound="top")
    exercise_label.pack(side="left", padx=10)

    meal_label = tk.Label(frame, image=meal_photo, text="Meals", compound="top")
    meal_label.pack(side="right", padx=10)

# Buttons for Navigation
tk.Button(root, text="Log Exercise", font=("Arial", 12), width=20, command=open_exercise_window).pack(pady=5)
tk.Button(root, text="Log Meal", font=("Arial", 12), width=20, command=open_meal_window).pack(pady=5)
tk.Button(root, text="View Progress", font=("Arial", 12), width=20, command=view_progress).pack(pady=5)
tk.Button(root, text="Exit", font=("Arial", 12), width=20, bg="red", fg="white", command=root.quit).pack(pady=10)

# Run Tkinter event loop
root.mainloop()
